##README##

This is a java application. To use, run Main.java within src with all other files in their appropriate places. 

You will be asked to give 3 inputs: The file containing the frequencies, the minimum support count, and the file containing the output. For the input and output, I recommend using .dat files as they are formatted well for the task. For output, I recommend using .txt . An example of an input would be T10I4D100K.dat and an output would be output.txt .

Any java IDE environment should work, but IntelliJ is preferred. 

Refer to output.txt for a what the output would look like for T10I4D100K.dat


NOTE:
3/4 
When I was working on the c4.5 and Bayesian classifier assignment, I reused the reader class I made for this project and I noticed that it only reads from the T100k file! I fixed the Reader.java so it actually reads your input correctly now (this was a 1 line fix) in case this hasn't been tested yet!